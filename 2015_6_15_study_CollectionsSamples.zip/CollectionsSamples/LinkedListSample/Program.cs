﻿
namespace Wrox.ProCSharp.Collections
{
  class Program
  {
    static void Main()
    {
      PriorityDocumentManager pdm = new PriorityDocumentManager();

	  Document doc1 = new Document("one", "Sample", 8);
	  Document doc2 = new Document("two", "Sample", 3);
	  Document doc3 = new Document("three", "Sample", 4);
	  Document doc4 = new Document("four", "Sample", 8);
	  Document doc5 = new Document("five", "Sample", 1);
	  Document doc6 = new Document("six", "Sample", 9);
	  Document doc7 = new Document("seven", "Sample", 1);
      Document doc8 = new Document("eight", "Sample", 1);


	  pdm.AddDocument(doc1);
	  pdm.AddDocument(doc2);
	  pdm.AddDocument(doc3);
	  pdm.AddDocument(doc4);
	  pdm.AddDocument(doc5);
	  pdm.AddDocument(doc6);
	  pdm.AddDocument(doc7);
	  pdm.AddDocument(doc8);

	  //pdm.AddDocument(new Document("one", "Sample", 8));
	  //pdm.AddDocument(new Document("two", "Sample", 3));
	  //pdm.AddDocument(new Document("three", "Sample", 4));
	  //pdm.AddDocument(new Document("four", "Sample", 8));
	  //pdm.AddDocument(new Document("five", "Sample", 1));
	  //pdm.AddDocument(new Document("six", "Sample", 9));
	  //pdm.AddDocument(new Document("seven", "Sample", 1));
	  //pdm.AddDocument(new Document("eight", "Sample", 1));

      pdm.DisplayAllNodes();

	  doc8 = new Document("hello", "Sample", 7);
	  pdm.DisplayAllNodes();
    }
  }
}
